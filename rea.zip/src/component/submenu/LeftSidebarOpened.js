import {MenuOutlinedIcon} from "../icons/icons";
import styles from "./LeftSidebarOpened.module.css"
import FigureSubmenu from './FigureSubmenu'
import TextBoxSubmenu from "./TextBoxSubmenu";
import LineSubmenu from "./LineSubmenu";
import ImageSubmenu from './ImageSubmenu';
import FilterSubmenu from './FilterSubmenu';
import CropSubmenu from "./CropSubmenu";
import { useEffect, useState } from "react";
import { ConsoleSqlOutlined } from "@ant-design/icons";
export default function LeftSidebarOpened(props) {
    const { toggleMenu, currentRoute,canvas,setCanvas, SetCurrentRoute}=props;
    //detail 한메뉴가 열리면 나머지가 닫히는 함수
    //필요없을 시 그냥 삭제
    //click으로 구현은 너무 비효율적
    // const details = document.querySelectorAll("details");
    // details.forEach((targetDetail) => {
    // targetDetail.addEventListener("click", () => {
    //     details.forEach((detail) => {
    //     if (detail !== targetDetail) {
    //         detail.removeAttribute("open");
    //     }
    //     });
    // });
    var flag = true;
    function Open(currentRoute, detailName) {
        if (currentRoute === detailName) {
            return true;
        } else {
            return false;
        }
    }
    const [menu,setMenu]=useState('');
    useEffect(()=>{
        console.log(currentRoute)
        if(currentRoute!=='Menu') document.querySelector('#'+currentRoute.toLowerCase()+'-detail').open=true
    },[currentRoute])
 
    function _setMenu(type){
        setMenu(type)
    }

    return (
        <>
        <MenuOutlinedIcon onClick={() => toggleMenu()} />
            <div className={styles.container}>
            <details className={styles.detail} id='object-detail' >
                <summary>Object</summary>
                {(currentRoute==='Object' || currentRoute==='Menu' )&&<FigureSubmenu canvas={canvas} addLayerItem={props.addLayerItem}/>}
                {/* <ImageSubmenu canvas={canvas}/> */}
            </details>

            {<details className={styles.detail} id='text-detail'   >
                <summary>Text</summary>
                {(currentRoute==='Text' ||currentRoute==='Menu'  )&&<TextBoxSubmenu canvas={canvas}/>}
            </details>}

            <details className={styles.detail} id='line-detail'  >
                <summary>Drawing</summary>
                {(currentRoute==='Line' || currentRoute==='Menu'  )&&<LineSubmenu canvas={canvas}/>}
            </details>

            <details className={styles.detail} id='image-detail'  >
                <summary>Canvas</summary>
                {(currentRoute==='Image' || currentRoute==='Menu'  )&&<FilterSubmenu canvas={canvas}/>}
            </details>
            
            <details className={styles.detail} id='crop-detail'   >
                <summary>Crop</summary>
                {(currentRoute==='Crop' || currentRoute==='Menu'  )&&<CropSubmenu canvas={canvas} setCanvas={setCanvas}/>}
            </details>
        </div>
        </>
    );
}